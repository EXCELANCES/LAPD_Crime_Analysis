

Drop TABLE Fact_Crime 
Drop  TABLE Time_Dimension 

Drop  TABLE Location_Dimension 

Drop TABLE CrimeType_Dimension 

Drop TABLE Status_Dimension 

Drop TABLE Victim_Dimension 
