CREATE DATABASE CrimeDataWarehouse;
GO

USE CrimeDataWarehouse;
GO
